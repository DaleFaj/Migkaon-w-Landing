import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyATmXoMKttmhS_lZyk-K6cNmw6TgvvgqUw",
    authDomain: "migkaon-ff96a.firebaseapp.com",
    projectId: "migkaon-ff96a",
    storageBucket: "migkaon-ff96a.appspot.com",
    messagingSenderId: "750100665431",
    appId: "1:750100665431:web:2f5be193edb3fb2f7b7f12"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const recipeContainer = document.getElementById('recipeContainer');
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');

let allRecipes = [];

async function fetchRecipes() {
    recipeContainer.innerHTML = "";
    const recipesRef = collection(db, "recipes");
    const querySnapshot = await getDocs(recipesRef);

    if (querySnapshot.empty) {
        recipeContainer.innerHTML = "<p class='no-recipes-message'>No recipes found.</p>";
    } else {
        allRecipes = [];
        querySnapshot.forEach((doc) => {
            const recipeData = doc.data();
            allRecipes.push(recipeData);
            displayRecipe(recipeData);
        });
    }
}

function displayRecipe(recipeData) {
    const recipeElement = document.createElement('div');
    recipeElement.classList.add('recipe-card');
    recipeElement.innerHTML = `
        <h3>${recipeData.name}</h3>
        <p><strong>Ingredients:</strong> ${recipeData.ingredients}</p>
        <p><strong>Instructions:</strong> ${recipeData.instructions}</p>
    `;
    recipeContainer.appendChild(recipeElement);
}

function filterRecipes(searchQuery) {
    recipeContainer.innerHTML = "";
    const filteredRecipes = allRecipes.filter(recipe => 
        recipe.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (filteredRecipes.length === 0) {
        recipeContainer.innerHTML = "<p class='no-recipes-message'>No recipes found.</p>";
    } else {
        filteredRecipes.forEach(displayRecipe);
    }
}

searchButton.addEventListener('click', () => {
    const searchQuery = searchInput.value.trim();
    filterRecipes(searchQuery);
});

searchInput.addEventListener('keyup', (event) => {
    if (event.key === 'Enter') {
        const searchQuery = searchInput.value.trim();
        filterRecipes(searchQuery);
    }
});

// Initial fetch without any search query
fetchRecipes();