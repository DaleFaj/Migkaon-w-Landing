import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, updateProfile, updatePassword } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore, doc, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyATmXoMKttmhS_lZyk-K6cNmw6TgvvgqUw",
    authDomain: "migkaon-ff96a.firebaseapp.com",
    projectId: "migkaon-ff96a",
    storageBucket: "migkaon-ff96a.appspot.com",
    messagingSenderId: "750100665431",
    appId: "1:750100665431:web:2f5be193edb3fb2f7b7f12"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const updateProfileForm = document.getElementById('updateProfileForm');

updateProfileForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const newUsername = document.getElementById('username').value;
    const newPassword = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;

    if (newPassword && newPassword !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    const user = auth.currentUser;

    try {
        if (newUsername) {
            await updateDoc(doc(db, "users", user.uid), {
                username: newUsername
            });
            await updateProfile(user, { displayName: newUsername });
        }

        if (newPassword) {
            await updatePassword(user, newPassword);
            alert("Password updated successfully!");
        }

        alert("Profile updated successfully!");
        window.location.href = "profile.html";
    } catch (error) {
        console.error("Error updating profile:", error);
        alert("Error updating profile. Please try again.");
    }
});