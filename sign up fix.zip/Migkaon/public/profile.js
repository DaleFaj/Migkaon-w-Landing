// scripts.js

function showTab(event, tabId) {
    // Hide all tab contents
    var tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(function (content) {
        content.style.display = 'none';
    });

    // Remove 'active' class from all tab links
    var tabLinks = document.querySelectorAll('.tab-link');
    tabLinks.forEach(function (link) {
        link.classList.remove('active');
    });

    // Show the selected tab content
    document.getElementById(tabId).style.display = 'block';

    // Add 'active' class to the clicked tab link
    event.currentTarget.classList.add('active');
}

// Show the first tab by default
document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.tab-link').click();
});

document.addEventListener('DOMContentLoaded', () => {
    fetch('/getRecipes')
        .then(response => response.json())
        .then(recipes => {
            const recipeContainer = document.getElementById('recipeContainer');
            recipes.forEach(recipe => {
                const recipeCard = document.createElement('div');
                recipeCard.className = 'recipe-card';

                const recipeImage = document.createElement('img');
                recipeImage.src = recipe.image ? recipe.image : 'assets/default_recipe_image.png';
                recipeImage.alt = recipe.name;

                const recipeName = document.createElement('div');
                recipeName.className = 'recipe-name';
                recipeName.textContent = recipe.name;

                const recipeIngredients = document.createElement('div');
                recipeIngredients.className = 'recipe-ingredients';
                recipeIngredients.textContent = `Ingredients: ${recipe.ingredients}`;

                const recipeInstructions = document.createElement('div');
                recipeInstructions.className = 'recipe-instructions';
                recipeInstructions.textContent = `Instructions: ${recipe.instructions}`;

                recipeCard.appendChild(recipeImage);
                recipeCard.appendChild(recipeName);
                recipeCard.appendChild(recipeIngredients);
                recipeCard.appendChild(recipeInstructions);
                recipeContainer.appendChild(recipeCard);
            });
        })
        .catch(error => {
            console.error('Error fetching recipes:', error);
        });
});
