const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');  
const session = require('express-session');  

const app = express();
const port = 3000;

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

const dbPath = path.join(__dirname, 'database', 'recipes.db');
const db = new sqlite3.Database(dbPath);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'your-secret-key', 
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  
}));

app.use(express.static(path.join(__dirname, 'public')));

const checkLogin = (req, res, next) => {
    if (req.session.username) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

app.post('/addRecipe', checkLogin, upload.single('image'), (req, res) => {
    const { recipeName, ingredients, instructions } = req.body;
    const image = req.file ? req.file.filename : null;
    const username = req.session.username;  

    if (!recipeName || !ingredients || !instructions) {
        return res.status(400).json({ error: 'Please provide all fields: recipeName, ingredients, instructions' });
    }

    const sql = `INSERT INTO recipes (name, ingredients, instructions, image, username) VALUES (?, ?, ?, ?, ?)`;
    db.run(sql, [recipeName, ingredients, instructions, image, username], function(err) {
        if (err) {
            console.error('Error adding recipe:', err.message);
            return res.status(500).json({ error: 'Failed to add recipe' });
        }
        console.log(`Recipe added with ID: ${this.lastID}`);
        res.status(200).send('Recipe added successfully');
    });
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }

    const sql = `SELECT * FROM profile_information WHERE username = ?`;
    db.get(sql, [username], async (err, row) => {
        if (err) {
            console.error('Error querying the database:', err.message);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (row) {
            try {
                const match = await bcrypt.compare(password, row.password);
                if (match) {
                    req.session.username = username;  
                    res.status(200).json({ success: true });
                } else {
                    res.status(401).json({ error: 'Invalid username or password' });
                }
            } catch (error) {
                console.error('Error comparing passwords:', error.message);
                res.status(500).json({ error: 'Internal server error' });
            }
        } else {
            res.status(401).json({ error: 'Invalid username or password' });
        }
    });
});

app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Failed to log out' });
        }
        res.status(200).json({ success: true });
    });
});

app.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const checkSql = `SELECT * FROM profile_information WHERE username = ? OR email = ?`;
        const row = await new Promise((resolve, reject) => {
            db.get(checkSql, [username, email], (err, row) => {
                if (err) {
                    console.error('Error querying the database:', err.message);
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });

        if (row) {
            return res.status(400).json({ error: 'Username or email already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const insertSql = `INSERT INTO profile_information (username, email, password) VALUES (?, ?, ?)`;
        await new Promise((resolve, reject) => {
            db.run(insertSql, [username, email, hashedPassword], function (err) {
                if (err) {
                    console.error('Error adding user:', err.message);
                    reject(err);
                } else {
                    console.log(`User added with ID: ${this.lastID}`);
                    resolve();
                }
            });
        });

        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Error hashing password or inserting user:', error.message);
        res.status(500).json({ error: 'Failed to sign up' });
    }
});

app.get('/landing.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'landing.html'));
});

app.post('/check-credentials', async (req, res) => {
    const { email, username } = req.body;

    const sql = `SELECT * FROM profile_information WHERE username = ? OR email = ?`;
    const row = await new Promise((resolve, reject) => {
        db.get(sql, [username, email], (err, row) => {
            if (err) {
                console.error('Error querying the database:', err.message);
                reject(err);
            } else {
                resolve(row);
            }
        });
    });

    res.json({ isUnique: !row });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
