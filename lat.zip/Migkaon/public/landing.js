document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const recipeContainer = document.getElementById('recipeContainer');

    searchButton.addEventListener('click', () => {
        const searchTerm = searchInput.value.trim().toLowerCase();
        if (searchTerm) {
            searchRecipes(searchTerm);
        }
    });

    fetchRecipes();
});

function fetchRecipes() {
    fetch('/getAllRecipes')
        .then(response => response.json())
        .then(recipes => displayRecipes(recipes))
        .catch(error => console.error('Error fetching recipes:', error));
}

function searchRecipes(term) {
    fetch(`/searchRecipes?term=${encodeURIComponent(term)}`)
        .then(response => response.json())
        .then(recipes => displayRecipes(recipes))
        .catch(error => console.error('Error searching recipes:', error));
}

function displayRecipes(recipes) {
    const container = document.getElementById('recipeContainer');
    container.innerHTML = recipes.map(recipe => `
        <div class="recipe-card" onclick="location.href='recipeDetail.html?id=${recipe.id}'">
            <img src="${recipe.image || 'assets/default_recipe_image.png'}" alt="${recipe.name}">
            <h3>${recipe.name}</h3>
        </div>
    `).join('');
}