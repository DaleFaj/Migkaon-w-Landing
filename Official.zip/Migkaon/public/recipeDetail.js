import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js';

const firebaseConfig = {
    apiKey: "AIzaSyCekHj77tQtXYwYaqArBjy6b846ODLodtc",
    authDomain: "tryy-3132a.firebaseapp.com",
    projectId: "tryy-3132a",
    storageBucket: "tryy-3132a.appspot.com", 
    messagingSenderId: "670802712817",
    appId: "1:670802712817:web:03adeaf0c10be278de3150"
};

// Initialize Firebase app
initializeApp(firebaseConfig);

// Initialize services
const db = getFirestore();

const recipeId = localStorage.getItem('recipeId');
if (recipeId) {
    const recipeRef = doc(db, 'recipes', recipeId);
    getDoc(recipeRef).then((doc) => {
        if (doc.exists()) {
            const recipe = doc.data();
            document.getElementById('recipeName').innerText = recipe.name;
            document.getElementById('recipeIngredients').innerText = recipe.ingredients;
            document.getElementById('recipeInstructions').innerText = recipe.instructions;
        } else {
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}