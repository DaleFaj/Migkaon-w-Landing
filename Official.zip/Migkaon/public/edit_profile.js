document.addEventListener('DOMContentLoaded', () => {
    // Fetch current user details
    fetch('/getCurrentUserDetails')
        .then(response => response.json())
        .then(data => {
            document.getElementById('email').value = data.email;
            document.getElementById('username').value = data.username;
        })
        .catch(error => console.error('Error fetching user details:', error));

    document.querySelector('form').addEventListener('submit', (event) => {
        event.preventDefault();

        const email = document.getElementById('email').value;
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;

        if (password && password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }

        const data = {
            newEmail: email,
            newUsername: username,
            newPassword: password || undefined
        };

        fetch('/updateUserDetails', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Profile updated successfully');
                window.location.href = 'profile.html';
            } else {
                alert(data.error);
            }
        })
        .catch(error => console.error('Error updating user details:', error));
    });
});
