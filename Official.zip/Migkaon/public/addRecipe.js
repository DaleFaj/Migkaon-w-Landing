import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, addDoc } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js';

const firebaseConfig = {
  apiKey: "AIzaSyCekHj77tQtXYwYaqArBjy6b846ODLodtc",
  authDomain: "tryy-3132a.firebaseapp.com",
  projectId: "tryy-3132a",
  storageBucket: "tryy-3132a.appspot.com", 
  messagingSenderId: "670802712817",
  appId: "1:670802712817:web:03adeaf0c10be278de3150"
};

// Initialize Firebase app
initializeApp(firebaseConfig);

// Initialize services
const db = getFirestore();
const auth = getAuth();

// Collection reference
const colRef = collection(db, 'recipes');

// Get current user and add recipe
onAuthStateChanged(auth, (user) => {
    if (user) {
        const username = user.displayName || "Anonymous";  // Fetch username from user profile

        const addRecipeForm = document.querySelector('.add');
        addRecipeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            addDoc(colRef, {
                name: addRecipeForm.recipeName.value,
                ingredients: addRecipeForm.ingredients.value,
                instructions: addRecipeForm.instructions.value,
                username: username
            }).then(() => {
                addRecipeForm.reset();
            });
        });
    }
});