import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, addDoc } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js';

const firebaseConfig = {
  apiKey: "AIzaSyATmXoMKttmhS_lZyk-K6cNmw6TgvvgqUw",
  authDomain: "migkaon-ff96a.firebaseapp.com",
  projectId: "migkaon-ff96a",
  storageBucket: "migkaon-ff96a.appspot.com",
  messagingSenderId: "750100665431",
  appId: "1:750100665431:web:2f5be193edb3fb2f7b7f12"
};
// Initialize Firebase app
initializeApp(firebaseConfig);

// Initialize services
const db = getFirestore();
const auth = getAuth();

// Collection reference
const colRef = collection(db, 'recipes');

// Get current user and add recipe
onAuthStateChanged(auth, (user) => {
  if (user) {
    const username = user.displayName || "Anonymous"; // Fetch username from user profile

    const addRecipeForm = document.querySelector('.add');
    addRecipeForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const recipeName = addRecipeForm.recipeName.value.trim();
      const ingredients = addRecipeForm.ingredients.value.trim();
      const instructions = addRecipeForm.instructions.value.trim();

      if (recipeName === "" || ingredients === "" || instructions === "") {
        alert("Please fill out all fields.");
        return;
      }

      try {
        await addDoc(colRef, {
          name: recipeName,
          ingredients: ingredients,
          instructions: instructions,
          username: username
        });
        alert("Recipe added successfully");
        addRecipeForm.reset();
      } catch (error) {
        console.error("Error adding document: ", error);
      }
    });
  }
});