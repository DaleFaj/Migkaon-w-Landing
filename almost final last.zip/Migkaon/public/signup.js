import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore, doc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyATmXoMKttmhS_lZyk-K6cNmw6TgvvgqUw",
    authDomain: "migkaon-ff96a.firebaseapp.com",
    projectId: "migkaon-ff96a",
    storageBucket: "migkaon-ff96a.appspot.com",
    messagingSenderId: "750100665431",
    appId: "1:750100665431:web:2f5be193edb3fb2f7b7f12"
  };

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const submit = document.getElementById('submit');
submit.addEventListener("click", function (event){
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const username = document.getElementById('username').value;

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
        // Signed up
        const user = userCredential.user;

        // Update the user's profile with the username
        updateProfile(user, {
            displayName: username
        }).then(() => {
            // Add the username to Firestore
            setDoc(doc(db, "users", user.uid), {
                email: email,
                username: username
            }).then(() => {
                alert("Account created successfully!");
                window.location.href = "index.html";
            }).catch((error) => {
                console.error("Error adding document: ", error);
                alert("Error adding username to database");
            });
        }).catch((error) => {
            console.error("Error updating profile: ", error);
            alert("Error updating profile");
        });
    })
    .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        alert(errorMessage);
    });
});