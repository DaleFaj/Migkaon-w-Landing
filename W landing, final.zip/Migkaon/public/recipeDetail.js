document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const recipeId = urlParams.get('id');

    if (recipeId) {
        const [recipe, userInfo] = await Promise.all([
            fetchRecipeDetails(recipeId),
            fetchUserInfo()
        ]);

        displayRecipeDetails(recipe, userInfo);
    } else {
        displayError('No recipe ID provided in the URL.');
    }
});

async function fetchRecipeDetails(recipeId) {
    try {
        const response = await fetch(`/getRecipeDetails/${recipeId}`);
        return response.json();
    } catch (error) {
        displayError('Error fetching recipe details: ' + error);
        throw error;
    }
}

async function fetchUserInfo() {
    try {
        const response = await fetch('/getUserInfo');
        return response.json();
    } catch (error) {
        console.error('Error fetching user info:', error);
        return null;
    }
}

function displayRecipeDetails(recipe, userInfo) {
    const container = document.getElementById('recipeDetailContainer');
    container.innerHTML = `
        <img src="${recipe.image || 'assets/default_recipe_image.png'}" alt="${recipe.name}">
        <h1>${recipe.name}</h1>
        <div>
            <h2>Ingredients</h2>
            <p>${recipe.ingredients}</p>
        </div>
        <div>
            <h2>Instructions</h2>
            <p>${recipe.instructions}</p>
        </div>
    `;

    if (userInfo && userInfo.username === recipe.username) {
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete Recipe';
        deleteButton.classList.add('delete-button');
        deleteButton.addEventListener('click', () => deleteRecipe(recipe.id));
        container.appendChild(deleteButton);
    }
}

function deleteRecipe(recipeId) {
    fetch(`/deleteRecipe/${recipeId}`, { method: 'DELETE' })
        .then(response => {
            if (response.ok) {
                alert('Recipe deleted successfully');
                window.location.href = 'landing.html'; // Redirect to landing page
            } else {
                response.json().then(data => alert(data.error));
            }
        })
        .catch(error => alert('Error deleting recipe: ' + error));
}

function displayError(message) {
    const container = document.getElementById('recipeDetailContainer');
    container.innerHTML = `<p class="error">${message}</p>`;
}